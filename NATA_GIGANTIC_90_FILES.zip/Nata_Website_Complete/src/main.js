import "./styles/tokens.css";
import "./styles/globals.css";
import "./styles/components.css";
import "./styles/animations.css";
import "./styles/responsive.css";

import { navbar } from "./components/Navbar.js";
import { footer } from "./components/Footer.js";
import { hero } from "./sections/Hero.js";
import { intro } from "./sections/Intro.js";
import { discover } from "./sections/Discover.js";
import { connections } from "./sections/Connections.js";
import { moments } from "./sections/Moments.js";
import { code } from "./sections/NataCode.js";
import { score } from "./sections/Score.js";
import { privacy } from "./sections/Privacy.js";
import { nati } from "./sections/Nati.js";
import { beta } from "./sections/Beta.js";
import { faq } from "./sections/FAQ.js";
import { initMenu } from "./lib/menu.js";
import { initReveal } from "./lib/reveal.js";
import { initModal } from "./lib/modal.js";
import { initCounters } from "./lib/counters.js";
import { initParallax } from "./lib/parallax.js";

document.querySelector("#app").innerHTML = [
  navbar(), hero(), intro(), discover(), connections(), moments(),
  code(), score(), privacy(), nati(), beta(), faq(), footer()
].join("");

initMenu();
initReveal();
initModal();
initCounters();
initParallax();
